var tvshow=[
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599316/list/00000004d9765b80dbe642d5a121ca361feb2143.jpg",
        text:"Happu Ki Ultan Paltan - February 22, 2022 - Episode Spoiler",
        smallText:"E 702",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599236/list/00000013ae1d187ce59f4a97ae8d1bc1604c8bb5.jpg",
        text:"Baal Shiv",
        smallText:"E 66",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599143/list/00000009763098f334fc472dbd1628fc69413258.jpg",
        text:"Meet ",
        smallText:"E 172",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599031/list/000000060a9ad90c83774b53b9ba187b6ed20c68.jpg",
        text:"Kashibai Bajirao Ballal ",
        smallText:"",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599019/list/00000007ffc0534639944b7b94603e85c2d99667.jpg",
        text:"Rishton ka Manjha",
        smallText:"E 157",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599043/list/00000012af028e9f0728401d81840769ec98b37b.jpg",
        text:"Iss Mod Se Jaate Hain",
        smallText:"E 68",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599171/list/00000008690a1dd3186b48609553cf0edf657a38.jpg",
        text:"Aggar Tum Na Hote ",
        smallText:"E 76",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599111/list/00000009621ed377f8c048e88ae6d631b83c2ef4.jpg",
        text:"Kumkum Bhagya ",
        smallText:"E 2069",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599052/list/00000005fe666d60942846da99923e1c0b5b018a.jpg",
        text:"Kundali Bhagya",
        smallText:"E 1182",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599060/list/00000006b1d34ebde0f94a01b8a319cd12e1f566.jpg",
        text:"Ek Mahanayak - Dr B R Ambedkar ",
        smallText:"E 496",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599268/list/000000067240c8eab1904f26825d925d2390d66f.jpg",
        text:"Tere Bina Jiya Jaye Na ",
        smallText:"E 76",
    },

    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599203/list/00000006db0c3195a06945258f92624a972c7d4c.jpg",
        text:"Tere Bina Jiya Jaye Na ",
        smallText:"E 76",
    },

    
  
]

localStorage.setItem("tvshow",JSON.stringify(tvshow));