var moviesData=[
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-4z587408/portrait/1920x770bb666424b608474e863f5bdfa0d4fec5.jpg",
        name:"Mithya",
        cat: "Action"
    },
    
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-4z560880/portrait/1920x7707e8711f6ada54ede80bd6c1fd7e5f289.jpg",
        name:"Kaun Banegi Shikharwati",
        cat: "Comedy"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3284/portrait/1920x77042e27986e8a34d8babc022e2285e4b3107b9f350f5b6426f9c1ba7409f59728a.jpg",
        name:"Sunflower",
        cat: "Comedy"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-1298/portrait/1920x770c938b03fb7cb450cb30780f100aef25d.jpg",
        name:"Abhay",
        cat: "Comedy"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2955/portrait/1920x7702bde888e01a54a1688ff0a84809a657aef9692fca19245ee980762d8461cfb17.jpg",
        name:"Jeet ki Zid",
        cat: "Horor"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3064/portrait/1920x770f6f1d5315e9145808275b6b69e6572f7.jpg",
        name:"Bicchoo ka Khel",
        cat: "Horor"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3502/portrait/1920x77096c3c9d32c6946bb933bef0e7463b7af.jpg",
        name:"Pavitra Rishta 2.0Its Never Too Late",
        cat: "Horor"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3044/portrait/063044incover98740071191a4d21bb818ea29d68541e.jpg",
        name:"Taish",
        cat: "Action"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2370/portrait/1920x770110fc27af01245fe87dd991bdf8ee49e.jpg",
        name:"State of Siege: 26/11",
        cat: "Comedy"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2395/portrait/062395incover18856015811885d96e4480c15e457f8b0b4c30a5883775.jpg",
        name:"Code M",
        cat: "Action"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3015/portrait/063015incover310180593.jpg",
        name:"Forbidden Love",
        cat: "Romance"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-1138/portrait/1920x7704cda9675b3584b50bd3129fb0fdb4979.jpg",
        name:"RangBaaz",
        cat: "Romance"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-4z543444/portrait/1920x770aafb9b5212694c7695e6bfe215ea0ff6.jpg",
        name:"Qatil Haseenaon Ke Naam",
        cat: "Drama"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-1558/portrait/061558incover.jpg",
        name:"POISON 2",
        cat: "Drama"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-tvshow_304564789/portrait/06tvshow3045641436360016.jpg",
        name:"Karenjit Kaur",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3444/portrait/1920x77000fb0aef19c44cba86897d8612b2758cbbab3c59cedd49a4b6d9a0f01eab56b5.jpg",
        name:"Break Point",
        cat: "Romance"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2923/portrait/1920x77088034308288034308265e8c0753ce34a6ebedc2dbf823a90ed.jpg",
        name:"Naksal Bari",
        cat: "Romance"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3189/portrait/063189incover163472758316341d85f68a7d9a473a85a5750bfab11ebd.jpg",
        name:"The Married Woman",
        cat: "Romance"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2176/portrait/1920x770b9b395ce22814c99b8217672c0e7deb7.jpg",
        name:"LalBazar",
        cat: "Romance"
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3172/portrait/063172incover782762971.jpg",
        name:"Dev DD 2",
        cat: "Comedy"
    }
    
  
]

localStorage.setItem("movies", JSON.stringify(moviesData));
