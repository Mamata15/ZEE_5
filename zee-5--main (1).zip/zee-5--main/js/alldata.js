allData = [

    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z517068/portrait/1920x770aa5981730b664d2ebd63cea1c0d3a489.jpg",
        name:"Thoda Gussa Thoda Pyaar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51017/portrait/1920x77068f6962f4b124bd7a162371a0915e3b2.jpg",
        name:"Nirahua Chalal London",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-19144/portrait/0019144cover538975139.jpg",
        name:"Dabang Sarkar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-nirahuachalalsasural/portrait/00nirahuachalalsasuralcov746333240b59a67fdcc00456a9e8d20e1904e6b20.jpg",
        name:"Nirahua Chalal Sasural 2",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51261/portrait/1920x77069864077637c4812915d97ccf96aee4a.jpg",
        name:"Jo Jeeta Wohi Sikandar",
        
    },


    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z513111/portrait/1920x770dfed6f74d7b24186a5739b423199c08e.jpg",
        name:"Jeena Marna Tere Sang",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-265644/portrait/1920x7701732222031.jpg",
        name:"Leke Aaja Band Baja Ae Pawan Raja",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-265780/portrait/1920x7702111095970.jpg",
        name:"Babbar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-257026/portrait/1920x770557973062.jpg",
        name:"Parvarish",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51620/portrait/1920x770inceda04401dfc4d67863f4d3f7d1b73e8.jpg",
        name:"Chutki Bhar Sindoor",
        
    },


    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z513111/portrait/1920x770dfed6f74d7b24186a5739b423199c08e.jpg",
        name:"Jeena Marna Tere Sang",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51017/portrait/1920x77068f6962f4b124bd7a162371a0915e3b2.jpg",
        name:"Nirahua Chalal London",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-movie_1577869076/portrait/jigar1920x770.jpg",
        name:"Jigar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z55609/portrait/1920x7701b85db0477a34b518f162045398ab7a7.jpg",
        name:"Dulhin Ganga Paar Ke",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51698/portrait/1920x770e5aa1f96a0a34a8ab8c4b5d1969ba64b.jpg",
        name:"Yadav Paan Bhandar",
        
    },



    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-movie_1259872199/portrait/00movie12598722098072721.jpg",
        name:"Mahabharat",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-19305/portrait/biwino11920x770.jpg",
        name:"Biwi No. 1",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z597182/portrait/1920x770c46471e3057849bf858e25be8e1a3088.jpg",
        name:"Daamadji",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z548495/portrait/1920x770388a96f8a09947019f62485b3f187b2b.jpg",
        name:"Diljale",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-142683/portrait/1920x770622255331.jpg",
        name:"Ghoonghat Mein Ghotala",
        
    },

    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z588913/portrait/1920x77062e38594ff8e4f5092d8f1ddd6e233cd.jpg",
        name:"Topnic",
        cat:"Drama",
    },
    
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-119468/portrait/00119468incove144662735.jpg",
        name:"Sudaksinar Sari",
        cat:"Drama",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z571422/portrait/1920x770845d575b57cb43599009f12008dba3a2.jpg",
        name:"Bini Sutoy",
        cat:"Drana",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-48836/portrait/0048836incover.jpg",
        name:"Onek Diner Por",
        cat:"Drama",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z541512/portrait/1920x770bbe9c8c511064804967dd0c4a427f0f0.jpg",
        name:"Comedy",
        cat:"Horor",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-bonolata/portrait/bonolota20151920x770.jpg",
        name:"Bonolota",
        cat:"Horor",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-42014/portrait/1920x770dac3a32c1fea44f38fa4f7a925828961c8a73dee1a834a7cb8cebd214512b104.jpg",
        name:"Bijaya",
        cat:"Drama",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-74622/portrait/satyamevajayate298776966.jpg",
        name:"Satyameva Jayate",
        cat:"Action",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-26040/portrait/jayojayodebi1920x770.jpg",
        name:"Joy Joy Debi",
        cat:"Comedy",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-ebhabeophireashajay/portrait/1920x7701429554124.jpg",
        name:"Avabeo Fire Asa Jai",
        cat:"Comedy",
    },

    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-399328/portrait/1920x77094fc5e4c855e4875bd8d022eb2c6ca5f.jpg",
        name:"Radhe - Your Most Wanted Bhai",
        cat:"Action",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-35166/portrait/1920x770a6695f542cf3419291a6bc299aa894f3.jpg",
        name:"Simba",
        cat:"Action",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-96839/portrait/1920x77062fa79ad2a00435ca0ef053f6a476a74.jpg",
        name:"Dream Girl",
        cat:"Romance",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-27132/portrait/1920x770d1edc80582d845ffadbb89aa802c967b5ee1a2f6dd514d9bb193c3c269165cc3.jpg",
        name:"Kedarnath",
        cat:"Romance",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-307715/portrait/00307715incov1533673836.jpg",
        name:"Suraj Pe Mangal Vari",
        cat:"Comedy",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-33204/portrait/1920x770ab13e3472dce436a9e87bcd9b77bfad4.jpg",
        name:"URI",
        cat:"Action",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-toiletekpremkatha/portrait/1920x7701497425846.jpg",
        name:"Toilet",
        cat:"Comedy",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-6728/portrait/006728incover12314315123104ac0c30c9504cd28e37143696169d67.jpg",
        name:"MULK",
        cat:"Thriller",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-122732/portrait/00122732incov1352570625135217a753ba57e64c269633ffe0a6fed413.jpg",
        name:"Hotel Mumbai",
        cat:"Thriller",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-4z587408/portrait/1920x770bb666424b608474e863f5bdfa0d4fec5.jpg",
        name:"Mithya",
        
    },
    
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-4z560880/portrait/1920x7707e8711f6ada54ede80bd6c1fd7e5f289.jpg",
        name:"Kaun Banegi Shikharwati",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3284/portrait/1920x77042e27986e8a34d8babc022e2285e4b3107b9f350f5b6426f9c1ba7409f59728a.jpg",
        name:"Sunflower",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-1298/portrait/1920x770c938b03fb7cb450cb30780f100aef25d.jpg",
        name:"Abhay",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2955/portrait/1920x7702bde888e01a54a1688ff0a84809a657aef9692fca19245ee980762d8461cfb17.jpg",
        name:"Jeet ki Zid",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3064/portrait/1920x770f6f1d5315e9145808275b6b69e6572f7.jpg",
        name:"Bicchoo ka Khel",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3502/portrait/1920x77096c3c9d32c6946bb933bef0e7463b7af.jpg",
        name:"Pavitra Rishta 2.0Its Never Too Late",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3044/portrait/063044incover98740071191a4d21bb818ea29d68541e.jpg",
        name:"Taish",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2370/portrait/1920x770110fc27af01245fe87dd991bdf8ee49e.jpg",
        name:"State of Siege: 26/11",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2395/portrait/062395incover18856015811885d96e4480c15e457f8b0b4c30a5883775.jpg",
        name:"Code M",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3015/portrait/063015incover310180593.jpg",
        name:"Forbidden Love",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-1138/portrait/1920x7704cda9675b3584b50bd3129fb0fdb4979.jpg",
        name:"RangBaaz",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-4z543444/portrait/1920x770aafb9b5212694c7695e6bfe215ea0ff6.jpg",
        name:"Qatil Haseenaon Ke Naam",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-1558/portrait/061558incover.jpg",
        name:"POISON 2",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-tvshow_304564789/portrait/06tvshow3045641436360016.jpg",
        name:"Karenjit Kaur",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3444/portrait/1920x77000fb0aef19c44cba86897d8612b2758cbbab3c59cedd49a4b6d9a0f01eab56b5.jpg",
        name:"Break Point",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2923/portrait/1920x77088034308288034308265e8c0753ce34a6ebedc2dbf823a90ed.jpg",
        name:"Naksal Bari",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3189/portrait/063189incover163472758316341d85f68a7d9a473a85a5750bfab11ebd.jpg",
        name:"The Married Woman",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-2176/portrait/1920x770b9b395ce22814c99b8217672c0e7deb7.jpg",
        name:"LalBazar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-6-3172/portrait/063172incover782762971.jpg",
        name:"Dev DD 2",
        
    }
]

localStorage.setItem("alldata", JSON.stringify(allData));