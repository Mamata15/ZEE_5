var tvshowData=[
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z598957/list/0000004230064b3e6ad54a8496f34107c04afda1.jpg",
        text:"Lakshmi Comes to Save Rishi",
        smallText:"E 170",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599118/list/000000167717b9aae10d4a2f8d21397f0115f9be.jpg",
        text:"Meet and Meet Ahlawat's Bond",
        smallText:"E 172",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z598961/list/00000236e0f80adeea094910bd781a4bd36ffe5a.jpg",
        text:"hea Gets Locked Up in Jail",
        smallText:"E 2069",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z598968/list/000001636378d2ab717f445282708eb77ea32b0e.jpg",
        text:"Prithvi Taunts Preeta",
        smallText:"E 1182",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599192/list/000002283651728ffb6f44438c10b2c00d65c094.jpg",
        text:"Will Anita Learn about Vibhuti’s Arrest?",
        smallText:"E 1751",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599305/list/00000227431c9869c5e047ef9de7fb0af458ab27.jpg",
        text:"Kamlesh Lodges a Complaint on Getting Robbed",
        smallText:"E 702",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599282/list/00000252904d5258edf2402ab6fdc539dfed3d2b.jpg",
        text:"The Thief Enters the Mansion as a Servant",
        smallText:"E 236",
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599226/list/0000019036b42bebc23046efb89f8c9a77df2070.jpg",
        text:"Veebhadra Kills Daksh",
        smallText:"E 66",
    },
    // {
    //     img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599148/list/00000143e78ba5bb68dd46c2a454ef7ee587bf06.jpg",
    //     text:"Aryan Batra Gives Paragi a Warning",
    //     smallText:"E 68",
    // },
    // {
    //     img_url:"https://akamaividz2.zee5.com/image/upload/w_407,h_229,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-1-6z599254/list/000002472f0bd5a4168d4726a0ea1670564b3c69.jpg",
    //     text:"Vaibhav Offers to Become Friends with Bhim",
    //     smallText:"E 496",
    // },

    
  
]

localStorage.setItem("tvshow", JSON.stringify(tvshowData))