var bhojpuriData=[
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z517068/portrait/1920x770aa5981730b664d2ebd63cea1c0d3a489.jpg",
        moviename:"Thoda Gussa Thoda Pyaar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51017/portrait/1920x77068f6962f4b124bd7a162371a0915e3b2.jpg",
        moviename:"Nirahua Chalal London",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-19144/portrait/0019144cover538975139.jpg",
        moviename:"Dabang Sarkar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-nirahuachalalsasural/portrait/00nirahuachalalsasuralcov746333240b59a67fdcc00456a9e8d20e1904e6b20.jpg",
        moviename:"Nirahua Chalal Sasural 2",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51261/portrait/1920x77069864077637c4812915d97ccf96aee4a.jpg",
        moviename:"Jo Jeeta Wohi Sikandar",
        
    },


    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z513111/portrait/1920x770dfed6f74d7b24186a5739b423199c08e.jpg",
        moviename:"Jeena Marna Tere Sang",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-265644/portrait/1920x7701732222031.jpg",
        moviename:"Leke Aaja Band Baja Ae Pawan Raja",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-265780/portrait/1920x7702111095970.jpg",
        moviename:"Babbar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-257026/portrait/1920x770557973062.jpg",
        moviename:"Parvarish",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51620/portrait/1920x770inceda04401dfc4d67863f4d3f7d1b73e8.jpg",
        moviename:"Chutki Bhar Sindoor",
        
    },


    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z513111/portrait/1920x770dfed6f74d7b24186a5739b423199c08e.jpg",
        moviename:"Jeena Marna Tere Sang",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51017/portrait/1920x77068f6962f4b124bd7a162371a0915e3b2.jpg",
        moviename:"Nirahua Chalal London",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-movie_1577869076/portrait/jigar1920x770.jpg",
        moviename:"Jigar",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z55609/portrait/1920x7701b85db0477a34b518f162045398ab7a7.jpg",
        moviename:"Dulhin Ganga Paar Ke",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z51698/portrait/1920x770e5aa1f96a0a34a8ab8c4b5d1969ba64b.jpg",
        moviename:"Yadav Paan Bhandar",
        
    },



    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-movie_1259872199/portrait/00movie12598722098072721.jpg",
        moviename:"Mahabharat",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-19305/portrait/biwino11920x770.jpg",
        moviename:"Biwi No. 1",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z597182/portrait/1920x770c46471e3057849bf858e25be8e1a3088.jpg",
        moviename:"Daamadji",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-1z548495/portrait/1920x770388a96f8a09947019f62485b3f187b2b.jpg",
        moviename:"Diljale",
        
    },
    {
        img_url:"https://akamaividz2.zee5.com/image/upload/w_321,h_482,c_scale,f_webp,q_auto:eco,dpr_2.0/resources/0-0-142683/portrait/1920x770622255331.jpg",
        moviename:"Ghoonghat Mein Ghotala",
        
    }
    
    
    
  
]

localStorage.setItem("bhopuri",JSON.stringify(bhojpuriData));