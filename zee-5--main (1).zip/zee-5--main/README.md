
<h1>Clone of Zee5 Website </h1>



<h1> Description </h1>
<p> As we started Masai School To build up our carrier as a MERN STACK DEVELOPER. I'm learning since Dec 2021. Now build a beautiful <a href="https://www.zee5.com/"> Zee5</a> Clone website with help of my colleagues and we these technologies HTML, CSS & JS.</p>
<p> During this project, we faced many issues likes- carousel, mobile responsive, but with help of our senior and google, we completed this website. </p>
<br>

<p> Following are the main technologies used in order to construct this frontend</p>
<li> <a href=""> HTML</a> </li>
<li> <a href=""> CSS</a> </li>
<li> <a href=""> JavaScript</a> </li>

<h1>Live Action 🌏 </h1>

ZEE5 CLONE {netlify}

<h1> Author ✍️</h1>

1. Durgesh Soni
2. Muskan Shaw
3. Prayash
4. Parimal
5. Vaibhav

![OUR TEAM (1)](https://user-images.githubusercontent.com/81063456/155844823-4b3181ca-2be4-470c-bbc4-d4712a20a788.png)

<h1>Home Page </h1>

![bg](https://user-images.githubusercontent.com/81063456/155761287-75fe7f35-0a95-477f-8b82-10e5212e86eb.png)

<h1>Slider Page </h1>

![bg3](https://user-images.githubusercontent.com/81063456/155765450-be22b654-aee9-413b-bf43-0de4ca4ea3b7.png)


<h1>Footer Page </h1>

![bg4](https://user-images.githubusercontent.com/81063456/155765515-3dca6886-61d4-4e19-9e2b-0257508eab0f.png)


<h1>Webseries Page </h1>

![bg5](https://user-images.githubusercontent.com/81063456/155765548-d71c74d6-27af-4c4c-a2f5-df0256feaef5.png)


<h1>Music Page </h1>

![bg6](https://user-images.githubusercontent.com/81063456/155765610-91520ba6-c24f-4e81-b798-9eb1d476c5a9.png)


<h1>Video Page </h1>

![bg7](https://user-images.githubusercontent.com/81063456/155765736-fd967068-cd3d-4ac3-8f5c-e4586b444bd7.png)


<h1>Login Page </h1>

![bg11](https://user-images.githubusercontent.com/81063456/155765816-39a7236d-f42e-434d-af89-d03b7492da36.png)


<h1>About Page </h1>

![bg12](https://user-images.githubusercontent.com/81063456/155765977-dcf751fe-1ec1-4429-ae40-1128aa156d29.png)

